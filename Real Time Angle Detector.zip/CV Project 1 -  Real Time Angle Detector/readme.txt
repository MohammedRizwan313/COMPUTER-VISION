Keep in mind you have all paths set for python and you're having a web camera for opencv module
install opencv-python and math library on python 3.5
Open cmd in this location
apply command:-  python AngleDetector.py
select three dots from mouse to calculate angle
and Voila it's done.